package com.docker.demo.learning_docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningDockerApplication.class, args);
	}

}
