package com.docker.demo.learning_docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
