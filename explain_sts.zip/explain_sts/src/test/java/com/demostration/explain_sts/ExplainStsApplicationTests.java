package com.demostration.explain_sts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExplainStsApplicationTests {

	@Test
	void contextLoads() {
	}

}
