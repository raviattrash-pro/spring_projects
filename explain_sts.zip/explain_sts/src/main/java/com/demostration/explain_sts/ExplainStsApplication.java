package com.demostration.explain_sts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExplainStsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExplainStsApplication.class, args);
	}

}
